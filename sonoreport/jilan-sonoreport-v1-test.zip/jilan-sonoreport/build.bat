@echo off
REM ============================================================
REM  Jilan SonoReport - build a single Windows .exe (PyInstaller)
REM  Run this file ON THE WINDOWS CLINIC PC, after setup steps
REM  in README.md are complete (Python + requirements installed).
REM
REM  Result:  dist\JilanSonoReport.exe
REM  Copy that .exe to any folder on the clinic PC together with
REM  templates.json and the "model" folder (Vosk voice model).
REM ============================================================

cd /d %~dp0

REM 1. Install PyInstaller (only needed once)
pip install pyinstaller

REM 2. Build one single .exe file (no console window)
pyinstaller --onefile --windowed --name JilanSonoReport sonoreport.py

echo.
echo Build finished. Find the program at: dist\JilanSonoReport.exe
echo Remember to keep templates.json and the "model" folder next to it.
pause
