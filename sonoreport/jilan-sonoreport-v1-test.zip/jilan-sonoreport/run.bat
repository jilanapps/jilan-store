@echo off
REM Jilan SonoReport - start the program on Windows
cd /d %~dp0
python sonoreport.py
pause
