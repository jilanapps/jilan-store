# Jilan SonoReport v1

Voice-driven ultrasound report builder for a Windows clinic PC.
Works **offline**. Patient data never leaves the PC.

## What it does

1. Enter patient details (Name, Age/Sex, Date auto-filled, Referred by).
2. Press Mic and speak the findings, or type them. Speech recognition
   runs offline with Vosk. If the microphone or voice model is missing,
   typing still works.
3. Speak or type a disease name. The app searches the local templates
   file (`templates.json`) and loads the matching organ blocks.
4. Tick Normal / Abnormal per organ and add measurements (mm).
5. The report preview builds itself: FINDINGS paragraphs + OPINION lines.
6. Add one or more scan photos with the file picker. Photos are
   embedded into the saved Word file, fitted to page width.
7. Press SAVE REPORT: a Word file named
   `PatientName_Date_Disease.docx` is saved into the `reports` folder,
   and one line is added to the local `register.csv`.
8. Press PRINT: the saved file opens in Word. Print from Word (Ctrl+P).
9. Press NEW REPORT to clear the form for the next patient.

## Setup on the clinic PC (Windows 10/11)

### Step 1 - Install Python

1. Open https://www.python.org/downloads/ in a browser.
2. Download Python 3.11 or newer for Windows and run the installer.
3. IMPORTANT: on the first installer screen, tick
   **"Add python.exe to PATH"**, then click Install.

### Step 2 - Copy the program folder

Copy the whole `jilan-sonoreport` folder to the clinic PC, for example
to `C:\JilanSonoReport`. Keep all files together in one folder.

### Step 3 - Install the required packages

1. Press Windows key + R, type `cmd`, press Enter.
2. Go to the folder:
   `cd C:\JilanSonoReport`
3. Run:
   `pip install -r requirements.txt`
   (Internet is needed only this once, for downloading the packages.)

### Step 4 - Download the voice model (one time only)

1. Open https://alphacephei.com/vosk/models in a browser.
2. Download the small English model:
   `vosk-model-small-en-us-0.15` (about 40 MB).
3. Unzip it inside the program folder and rename the unzipped folder
   to `model`, so the program folder contains:
   `sonoreport.py`, `report_logic.py`, `templates.json`, `model\`.

Without this folder, the Mic button will show a message and typing
still works. Nothing else breaks.

### Step 5 - Run the program

Double-click `run.bat`, or in the command window run:

`python sonoreport.py`

A headset microphone is recommended in a noisy clinic room, so only
your voice is heard clearly.

## Making a single .exe file (optional, later)

On the Windows PC, after setup is complete, double-click `build.bat`.
It creates `dist\JilanSonoReport.exe`. Copy that .exe together with
`templates.json` and the `model` folder to run the program without
Python. Do not try to build the .exe on a Linux machine.

## Templates folder setting (your 600 clinic templates)

On first run, the program asks if you want to pick your clinic
templates folder (the folder with your disease-named Word files).
If you pick it:

- The program indexes the disease names from the FILE NAMES in that
  folder (including subfolders). Search then covers all your
  templates, and folder results appear first, marked `[Folder]`.
- Click a folder result to see its file, then open it in Word with
  the button and edit it as before. The built-in checklist builder
  works with the built-in templates in `templates.json`.
- If you skip the folder choice, the program keeps working with the
  built-in templates only. You can pick or clear the folder later
  with the buttons under the disease search.
- Privacy: only file names are indexed. File contents are never
  opened, read, copied, or uploaded anywhere. The folder choice is
  saved in `settings.json` next to the program.

## Editing the templates

Open `templates.json` in Notepad. Each template has a disease name,
keywords, and organ blocks with `normal` and `abnormal` text plus
opinion lines. Add new disease blocks in the same format and restart
the program. Keep the wording generic - never paste real patient
findings, names, or measurements into this file.

## Files in this folder

- `sonoreport.py` - the program (tkinter user interface).
- `report_logic.py` - report building, Word saving, register logic.
- `templates.json` - editable local templates store (generic samples).
- `requirements.txt` - Python packages needed.
- `run.bat` - starts the program on Windows.
- `build.bat` - builds a single .exe with PyInstaller on Windows.
- `README.md` - this file.
- `TEST-REPORT.md` - what was tested and what is still untested.
- `reports\` - created on first save; saved Word reports go here.
- `register.csv` - created on first save; one line per saved report.

## Privacy

All reports and the register stay on the clinic PC. The program sends
no data to any website or server. Voice recognition runs locally with
the downloaded Vosk model.
