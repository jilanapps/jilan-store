"""Non-GUI core logic for Jilan SonoReport.

This module has no tkinter dependency, so it can be tested headlessly.
All patient data stays on the local PC. Templates come from templates.json
and contain only generic sample wording - never real patient findings.
"""

import csv
import json
import os
import re
from datetime import date

from docx import Document
from docx.shared import Inches

REPORTS_DIR = "reports"
REGISTER_FILE = "register.csv"
SETTINGS_FILE = "settings.json"
TEMPLATE_EXTS = (".doc", ".docx")


def disease_name_from_filename(path):
    """Turn a template file name into a disease name.

    Only the file NAME is used - never the file content.
    Underscores and dashes become spaces.
    """
    stem = os.path.splitext(os.path.basename(path))[0]
    name = re.sub(r"[_-]+", " ", stem).strip()
    name = re.sub(r"\s+", " ", name)
    return name


def index_template_folder(folder):
    """Index disease names from template FILENAMES in a folder.

    Scans recursively for .doc/.docx files and records each file's
    disease name and path. File contents are never opened, read, or
    uploaded anywhere. Returns a list of folder-template dicts.
    """
    entries = []
    if not folder or not os.path.isdir(folder):
        return entries
    for root, _dirs, files in os.walk(folder):
        for fn in sorted(files):
            if fn.lower().endswith(TEMPLATE_EXTS):
                full = os.path.join(root, fn)
                disease = disease_name_from_filename(full)
                if disease:
                    entries.append({
                        "disease": disease,
                        "source": "folder",
                        "file": full,
                        "keywords": [disease.lower()],
                        "organs": [],
                    })
    return entries


def combined_search(query, folder_templates, json_templates):
    """Search folder index first, then JSON templates.

    The local folder index takes priority when present: folder matches
    come first, and a disease name already found in the folder is not
    repeated from the JSON store. Empty query returns [].
    """
    if not (query or "").strip():
        return []
    out = []
    seen = set()
    for t in search_templates(query, folder_templates) + search_templates(query, json_templates):
        key = t.get("disease", "").lower()
        if key not in seen:
            seen.add(key)
            out.append(t)
    return out


def load_settings(path):
    """Load settings JSON; returns {} when missing or unreadable."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_settings(path, data):
    """Persist settings JSON next to the program."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return path


def load_templates(path):
    """Load the templates store. Returns a list of template dicts."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("templates", [])


def search_templates(query, templates):
    """Case-insensitive substring match on disease name and keywords.

    Returns matching templates in store order. Empty query returns [].
    """
    q = (query or "").strip().lower()
    if not q:
        return []
    hits = []
    for t in templates:
        if q in t.get("disease", "").lower():
            hits.append(t)
            continue
        for kw in t.get("keywords", []):
            if q in kw.lower() or kw.lower() in q:
                hits.append(t)
                break
    return hits


def assemble_report(patient, selections):
    """Build FINDINGS paragraphs and OPINION lines.

    patient: dict with name, age_sex, date, referred_by, disease.
    selections: list of dicts: {organ, state ('normal'|'abnormal'),
    measurement (str, may be ''), normal, abnormal,
    opinion_normal, opinion_abnormal}.

    Returns (findings_text, opinion_lines).
    """
    findings_paras = []
    opinion_lines = []
    for s in selections:
        state = s.get("state", "normal")
        if state == "abnormal" and s.get("abnormal"):
            text = s["abnormal"]
            opinion = s.get("opinion_abnormal", "")
        else:
            text = s.get("normal", "")
            opinion = s.get("opinion_normal", "")
        meas = (s.get("measurement") or "").strip()
        if meas:
            text = text.rstrip() + " Measurement noted: %s mm." % meas
        if text:
            findings_paras.append("%s: %s" % (s.get("organ", ""), text))
        if opinion:
            opinion_lines.append(opinion)
    if not findings_paras:
        findings_paras.append("No findings selected.")
    if not opinion_lines:
        opinion_lines.append("Normal study.")
    findings_text = "\n".join(findings_paras)
    return findings_text, opinion_lines


def safe_filename(name):
    """Strip characters that are illegal in Windows file names."""
    name = re.sub(r'[<>:"/\\|?*]', "", name or "")
    name = re.sub(r"\s+", "_", name.strip())
    return name or "Patient"


def make_filename(patient_name, report_date, disease):
    """PatientName_Date_Disease.docx (date as YYYY-MM-DD)."""
    base = "%s_%s_%s" % (
        safe_filename(patient_name),
        (report_date or str(date.today())).strip(),
        safe_filename(disease),
    )
    return base + ".docx"


def save_docx(path, patient, findings_text, opinion_lines, photo_paths):
    """Write the report as a .docx file.

    Layout: title, patient details block, FINDINGS paragraphs, OPINION
    lines, then each photo auto-fitted to page width (max 6 inches wide).
    Returns the path written.
    """
    doc = Document()
    doc.add_heading("ULTRASOUND REPORT", level=0)
    details = doc.add_paragraph()
    details.add_run("Patient Name: ").bold = True
    details.add_run(patient.get("name", "") + "\n")
    details.add_run("Age / Sex: ").bold = True
    details.add_run(patient.get("age_sex", "") + "\n")
    details.add_run("Date: ").bold = True
    details.add_run(patient.get("date", "") + "\n")
    details.add_run("Referred by: ").bold = True
    details.add_run(patient.get("referred_by", "") + "\n")
    details.add_run("Examination: ").bold = True
    details.add_run(patient.get("disease", ""))
    doc.add_heading("FINDINGS", level=1)
    for para in findings_text.split("\n"):
        if para.strip():
            doc.add_paragraph(para)
    doc.add_heading("OPINION", level=1)
    for i, line in enumerate(opinion_lines, start=1):
        doc.add_paragraph("%d. %s" % (i, line))
    if photo_paths:
        doc.add_heading("IMAGES", level=1)
        for photo in photo_paths:
            if photo and os.path.exists(photo):
                doc.add_picture(photo, width=Inches(6))
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    doc.save(path)
    return path


def append_register(register_path, patient, file_path):
    """Append one line: date, patient name, age/sex, disease, file path."""
    exists = os.path.exists(register_path)
    with open(register_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if not exists:
            writer.writerow(["Date", "Patient Name", "Age/Sex", "Disease", "File Path"])
        writer.writerow([
            patient.get("date", ""),
            patient.get("name", ""),
            patient.get("age_sex", ""),
            patient.get("disease", ""),
            file_path,
        ])
    return register_path
