# Jilan SonoReport v1 - TEST REPORT

Date tested: 2026-11-03 (on a Linux test machine, NOT on the clinic PC).
Tester: automated build check.

## What was tested HERE (and passed)

1. Template search: searching "gall bladder" returns the Gall Bladder
   template from `templates.json`.
2. Report assembly: Gall Bladder Abnormal + a measurement produces a
   FINDINGS paragraph and an OPINION line; empty selections fall back
   to "Normal study."
3. Word file saving: a sample `.docx` was generated with
   `PatientName_Date_Disease.docx` naming
   (`Test_Patient_2026-11-03_Gall_Bladder.docx`).
4. Round-trip read: the saved `.docx` was reopened with python-docx
   and confirmed to contain the FINDINGS heading, the OPINION heading,
   the findings text, and 1 embedded photo (inline shape count = 1).
5. Register: one line was appended to `register.csv` with date, patient
   name, age/sex, disease, and file path.
6. Code quality: `python -m py_compile` passes for `sonoreport.py`
   and `report_logic.py`; both modules import cleanly.
7. User interface: the tkinter window was created and ran under a
   virtual display (Xvfb) and exited cleanly. All sections were
   present: patient form, voice, disease search, findings checklist,
   report preview, photos, and action buttons.
8. Language check: a non-ASCII scan of all program files found no
   non-English text. The UI is 100% English.
9. Templates folder indexing: a test folder with 5 Word files (plus
   one ignored .txt file and one file in a subfolder) indexed exactly
   the 5 disease names from file names only. Combined search puts
   folder matches first ("Gall Bladder Stone" from the folder before
   the built-in "Gall Bladder"), still finds JSON-only templates, and
   works with no folder set. Settings save/load round-trip passed.
   The GUI launches with the folder row showing
   "Templates folder: not set (built-in templates only)."

Sample test files were written to a temporary folder only; no sample
patient data was added to the project itself. The seeded templates
contain generic wording only.

## What is UNTESTED and must be tested on the real clinic PC

- Voice recognition accuracy with the Vosk small English model, and
  microphone/headset behaviour in a noisy clinic room. (Vosk and
  PyAudio were not installed on this test machine, and no voice model
  was downloaded here.)
- The Windows setup steps in README.md: Python install, pip install,
  voice-model download, and `python sonoreport.py` launch.
- Printing: the Print button opens the saved `.docx` in Word; actual
  printing from Word was not tested.
- Real template editing: adding the clinic's own disease blocks to
  `templates.json` and checking they load correctly.
- Indexing the real 600-file templates folder on the clinic PC and
  confirming search covers all of them and folder results open in
  Word correctly.
- Performance and display on the clinic PC's screen size.

## Honest status

This is a TEST version. It is NOT claimed to work on the clinic PC
until the user tests it there. If any step fails on the clinic PC,
report the exact error message shown and the step it failed on.
