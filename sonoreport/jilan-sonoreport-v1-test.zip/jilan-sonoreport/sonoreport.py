"""Jilan SonoReport v1 - voice-driven ultrasound report builder (offline).

Windows 10/11 clinic PC program. UI language: English only.
Patient data never leaves this PC. Voice recognition runs offline with Vosk;
if the microphone or the Vosk model is unavailable, typing still works -
voice never blocks the report workflow.

Run:  python sonoreport.py
First-time setup is documented in README.md.
"""

import json
import os
import queue
import sys
import threading
import tkinter as tk
from datetime import date
from tkinter import filedialog, messagebox, ttk

from report_logic import (
    REPORTS_DIR,
    REGISTER_FILE,
    SETTINGS_FILE,
    append_register,
    assemble_report,
    combined_search,
    index_template_folder,
    load_settings,
    load_templates,
    make_filename,
    save_settings,
    save_docx,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_PATH = os.path.join(BASE_DIR, "templates.json")
SETTINGS_PATH = os.path.join(BASE_DIR, SETTINGS_FILE)

try:
    from vosk import KaldiRecognizer, Model
    VOSK_AVAILABLE = True
except Exception:
    VOSK_AVAILABLE = False

try:
    import pyaudio
    PYAUDIO_AVAILABLE = True
except Exception:
    PYAUDIO_AVAILABLE = False


def find_vosk_model():
    """Look for a downloaded Vosk small English model next to the script."""
    for cand in ("model", "vosk-model-small-en-us-0.15"):
        path = os.path.join(BASE_DIR, cand)
        if os.path.isdir(path):
            return path
    return None


class SonoReportApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Jilan SonoReport")
        self.geometry("980x760")
        self.templates = []
        try:
            self.templates = load_templates(TEMPLATES_PATH)
        except Exception as exc:
            messagebox.showwarning("Templates", "Could not load templates.json: %s" % exc)
        # Templates folder setting: disease names indexed from FILENAMES
        # only. No template file content is ever read or uploaded.
        self.settings = load_settings(SETTINGS_PATH)
        self.folder_templates = []
        folder = self.settings.get("templates_folder", "")
        if folder:
            self.folder_templates = index_template_folder(folder)
        self.current_template = None
        self.organ_rows = []  # list of dicts: organ, state_var, meas_entry
        self.photos = []     # list of file paths
        self.voice_thread = None
        self.voice_stop = threading.Event()
        self.voice_queue = queue.Queue()
        self.voice_on = False
        self._build_ui()
        self._refresh_preview()
        self._update_folder_label()
        # First run only: offer to pick the clinic templates folder.
        # Skipping is fine - the app keeps working with the built-in
        # JSON templates. This prompt is shown only once.
        if not self.settings.get("folder_prompted"):
            self.settings["folder_prompted"] = True
            save_settings(SETTINGS_PATH, self.settings)
            if messagebox.askyesno(
                "Templates folder",
                "Do you want to pick your clinic templates folder now?\n"
                "The app will index disease names from the file names in "
                "that folder, so search covers all your templates.\n"
                "No file is ever copied or uploaded anywhere.\n\n"
                "Choose No to keep using the built-in templates only. "
                "You can pick a folder later with the button below."):
                self._choose_folder()

    # ---------------- UI construction ----------------
    def _build_ui(self):
        main = ttk.Frame(self, padding=10)
        main.pack(fill=tk.BOTH, expand=True)

        # 1. Patient details
        pf = ttk.LabelFrame(main, text="1. Patient Details", padding=8)
        pf.pack(fill=tk.X, pady=4)
        ttk.Label(pf, text="Name:").grid(row=0, column=0, sticky=tk.W)
        self.name_entry = ttk.Entry(pf, width=40)
        self.name_entry.grid(row=0, column=1, padx=4, sticky=tk.W)
        ttk.Label(pf, text="Age / Sex:").grid(row=0, column=2, sticky=tk.W)
        self.age_entry = ttk.Entry(pf, width=14)
        self.age_entry.grid(row=0, column=3, padx=4, sticky=tk.W)
        ttk.Label(pf, text="Date:").grid(row=1, column=0, sticky=tk.W, pady=4)
        self.date_entry = ttk.Entry(pf, width=20)
        self.date_entry.insert(0, date.today().isoformat())
        self.date_entry.grid(row=1, column=1, padx=4, sticky=tk.W, pady=4)
        ttk.Label(pf, text="Referred by:").grid(row=1, column=2, sticky=tk.W)
        self.ref_entry = ttk.Entry(pf, width=30)
        self.ref_entry.grid(row=1, column=3, padx=4, sticky=tk.W)

        # 2. Voice input
        vf = ttk.LabelFrame(main, text="2. Speak to Write Findings", padding=8)
        vf.pack(fill=tk.X, pady=4)
        self.mic_btn = ttk.Button(vf, text="Mic: Start Listening", command=self._toggle_voice)
        self.mic_btn.pack(side=tk.LEFT, padx=4)
        ttk.Label(vf, text="Press mic, speak - the system will type it.").pack(side=tk.LEFT, padx=4)
        self.voice_status = ttk.Label(vf, text=self._voice_status_text())
        self.voice_status.pack(side=tk.LEFT, padx=8)
        self.spoken_box = tk.Text(vf, height=3, width=100, wrap=tk.WORD)
        self.spoken_box.pack(fill=tk.X, pady=4)
        self.spoken_box.bind("<KeyRelease>", lambda e: self._refresh_preview())

        # 3. Disease / template search
        df = ttk.LabelFrame(main, text="3. Disease / Template", padding=8)
        df.pack(fill=tk.X, pady=4)
        ttk.Label(df, text="Speak or type disease name:").pack(side=tk.LEFT)
        self.disease_entry = ttk.Entry(df, width=35)
        self.disease_entry.pack(side=tk.LEFT, padx=4)
        self.disease_entry.bind("<KeyRelease>", self._on_disease_typed)
        ttk.Button(df, text="Search", command=self._on_disease_typed).pack(side=tk.LEFT, padx=4)
        self.match_list = tk.Listbox(df, height=3, width=60)
        self.match_list.pack(fill=tk.X, pady=4)
        self.match_list.bind("<<ListboxSelect>>", self._on_template_selected)
        # Templates folder setting row
        tf = ttk.Frame(df)
        tf.pack(fill=tk.X, pady=2)
        self.folder_label = ttk.Label(tf, text="Templates folder: not set (built-in templates only).")
        self.folder_label.pack(side=tk.LEFT, padx=4)
        ttk.Button(tf, text="Choose folder...", command=self._choose_folder).pack(side=tk.LEFT, padx=4)
        ttk.Button(tf, text="Clear", command=self._clear_folder).pack(side=tk.LEFT, padx=4)

        # 4. Findings checklist
        ff = ttk.LabelFrame(main, text="4. Findings (tick Normal / Abnormal)", padding=8)
        ff.pack(fill=tk.X, pady=4)
        self.findings_frame = ttk.Frame(ff)
        self.findings_frame.pack(fill=tk.X)

        # 5. Report preview
        pv = ttk.LabelFrame(main, text="5. Report Preview (auto-generated)", padding=8)
        pv.pack(fill=tk.BOTH, expand=True, pady=4)
        self.preview_box = tk.Text(pv, height=12, width=100, wrap=tk.WORD, state=tk.DISABLED)
        self.preview_box.pack(fill=tk.BOTH, expand=True)

        # 6. Photos
        ph = ttk.LabelFrame(main, text="6. Scan Photos", padding=8)
        ph.pack(fill=tk.X, pady=4)
        ttk.Button(ph, text="Add Photo...", command=self._add_photo).pack(side=tk.LEFT, padx=4)
        ttk.Button(ph, text="Remove Last Photo", command=self._remove_photo).pack(side=tk.LEFT, padx=4)
        self.photo_label = ttk.Label(ph, text="No photos added.")
        self.photo_label.pack(side=tk.LEFT, padx=8)

        # 7. Actions
        af = ttk.Frame(main, padding=4)
        af.pack(fill=tk.X, pady=4)
        ttk.Button(af, text="SAVE REPORT", command=self._save_report).pack(side=tk.LEFT, padx=4)
        ttk.Button(af, text="PRINT (open in Word)", command=self._print_report).pack(side=tk.LEFT, padx=4)
        ttk.Button(af, text="NEW REPORT", command=self._new_report).pack(side=tk.LEFT, padx=4)
        self.status = ttk.Label(af, text="Ready.")
        self.status.pack(side=tk.LEFT, padx=8)
        ttk.Label(main, text="File auto-saves as PatientName_Date_Disease.docx - Register entry also auto.").pack(fill=tk.X, pady=2)

    def _voice_status_text(self):
        if not VOSK_AVAILABLE:
            return "Voice unavailable (Vosk not installed) - typing works."
        if not PYAUDIO_AVAILABLE:
            return "Voice unavailable (microphone library missing) - typing works."
        if not find_vosk_model():
            return "Voice model not found - see README step 4. Typing works."
        return "Voice ready (offline)."

    # ---------------- voice ----------------
    def _toggle_voice(self):
        if self.voice_on:
            self.voice_stop.set()
            self.voice_on = False
            self.mic_btn.config(text="Mic: Start Listening")
            self.voice_status.config(text="Listening stopped.")
            return
        if not (VOSK_AVAILABLE and PYAUDIO_AVAILABLE):
            messagebox.showinfo("Voice", "Voice is not available on this PC. Please type instead.")
            return
        model_path = find_vosk_model()
        if not model_path:
            messagebox.showinfo(
                "Voice model",
                "Vosk model folder not found next to sonoreport.py.\n"
                "See README.md step 4 to download it once.\n"
                "Meanwhile, please type instead.",
            )
            return
        self.voice_stop.clear()
        self.voice_on = True
        self.mic_btn.config(text="Mic: STOP Listening")
        self.voice_status.config(text="Listening... speak now.")
        self.voice_thread = threading.Thread(
            target=self._voice_worker, args=(model_path,), daemon=True
        )
        self.voice_thread.start()
        self.after(200, self._drain_voice_queue)

    def _voice_worker(self, model_path):
        try:
            model = Model(model_path)
            rec = KaldiRecognizer(model, 16000)
            rec.SetWords(True)
            pa = pyaudio.PyAudio()
            stream = pa.open(format=pyaudio.paInt16, channels=1,
                             rate=16000, input=True, frames_per_buffer=4000)
            stream.start_stream()
            while not self.voice_stop.is_set():
                data = stream.read(4000, exception_on_overflow=False)
                if rec.AcceptWaveform(data):
                    result = json.loads(rec.Result())
                    text = result.get("text", "").strip()
                    if text:
                        self.voice_queue.put(text)
                else:
                    partial = json.loads(rec.PartialResult()).get("partial", "")
                    if partial:
                        self.voice_queue.put("\x00" + partial)
            stream.stop_stream()
            stream.close()
            pa.terminate()
        except Exception as exc:
            self.voice_queue.put("\x01" + str(exc))

    def _drain_voice_queue(self):
        try:
            while True:
                item = self.voice_queue.get_nowait()
                if item.startswith("\x01"):
                    self.voice_status.config(text="Voice error: %s" % item[1:])
                    self.voice_on = False
                    self.mic_btn.config(text="Mic: Start Listening")
                elif item.startswith("\x00"):
                    self.voice_status.config(text="Heard: %s" % item[1:])
                else:
                    self.spoken_box.insert(tk.END, item + " ")
                    self.voice_status.config(text="Listening... text added below.")
                    self._refresh_preview()
        except queue.Empty:
            pass
        if self.voice_on:
            self.after(200, self._drain_voice_queue)

    def _update_folder_label(self):
        folder = self.settings.get("templates_folder", "")
        if folder and self.folder_templates:
            self.folder_label.config(
                text="Templates folder: %s (%d files indexed)"
                % (folder, len(self.folder_templates)))
        elif folder:
            self.folder_label.config(
                text="Templates folder: %s (no template files found)" % folder)
        else:
            self.folder_label.config(
                text="Templates folder: not set (built-in templates only).")

    def _choose_folder(self):
        folder = filedialog.askdirectory(title="Pick your clinic templates folder")
        if not folder:
            return
        self.settings["templates_folder"] = folder
        save_settings(SETTINGS_PATH, self.settings)
        self.folder_templates = index_template_folder(folder)
        self._update_folder_label()
        self._on_disease_typed()
        self.status.config(text="Folder indexed: %d template files." % len(self.folder_templates))

    def _clear_folder(self):
        self.settings["templates_folder"] = ""
        save_settings(SETTINGS_PATH, self.settings)
        self.folder_templates = []
        self._update_folder_label()
        self._on_disease_typed()
        self.status.config(text="Templates folder cleared - using built-in templates.")

    def _open_folder_template(self):
        path = (self.current_template or {}).get("file", "")
        if not path or not os.path.exists(path):
            messagebox.showwarning("Template file", "Template file not found:\n%s" % path)
            return
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)
            else:
                import subprocess
                subprocess.Popen(["xdg-open", path])
            self.status.config(text="Opened template file in Word.")
        except Exception as exc:
            messagebox.showerror("Template file", "Could not open the file: %s" % exc)

    # ---------------- disease / findings ----------------
    def _on_disease_typed(self, event=None):
        query = self.disease_entry.get()
        self.match_list.delete(0, tk.END)
        # Folder index first (priority), then built-in JSON templates.
        self._matches = combined_search(query, self.folder_templates, self.templates)
        for t in self._matches:
            label = t["disease"]
            if t.get("source") == "folder":
                label = "[Folder] " + label
            self.match_list.insert(tk.END, label)

    def _on_template_selected(self, event=None):
        sel = self.match_list.curselection()
        if not sel:
            return
        self.current_template = self._matches[sel[0]]
        self.status.config(text="Template found: %s" % self.current_template["disease"])
        for widget in self.findings_frame.winfo_children():
            widget.destroy()
        self.organ_rows = []
        if self.current_template.get("source") == "folder":
            # Folder templates are indexed by FILENAME only, so there are
            # no organ blocks to tick. Offer the original file in Word.
            ttk.Label(self.findings_frame,
                      text="Template file: %s" % self.current_template.get("file", ""),
                      wraplength=900).pack(anchor=tk.W, padx=4, pady=4)
            ttk.Button(self.findings_frame, text="Open template file in Word",
                       command=self._open_folder_template).pack(anchor=tk.W, padx=4, pady=4)
            ttk.Label(self.findings_frame,
                      text="Tip: pick a built-in template for the checklist builder, "
                      "or open this file and edit it in Word as before.").pack(
                          anchor=tk.W, padx=4, pady=4)
            self._refresh_preview()
            return
        for i, organ in enumerate(self.current_template.get("organs", [])):
            ttk.Label(self.findings_frame, text=organ["name"]).grid(
                row=i, column=0, sticky=tk.W, padx=4, pady=2)
            state_var = tk.StringVar(value="normal")
            ttk.Radiobutton(self.findings_frame, text="Normal", variable=state_var,
                            value="normal", command=self._refresh_preview).grid(
                                row=i, column=1, padx=4)
            if organ.get("abnormal"):
                ttk.Radiobutton(self.findings_frame, text="Abnormal", variable=state_var,
                                value="abnormal", command=self._refresh_preview).grid(
                                    row=i, column=2, padx=4)
            ttk.Label(self.findings_frame, text="Measurement (mm):").grid(
                row=i, column=3, sticky=tk.W, padx=4)
            meas = ttk.Entry(self.findings_frame, width=10)
            meas.grid(row=i, column=4, padx=4)
            meas.bind("<KeyRelease>", lambda e: self._refresh_preview())
            self.organ_rows.append({
                "organ": organ["name"],
                "normal": organ.get("normal", ""),
                "abnormal": organ.get("abnormal", ""),
                "opinion_normal": organ.get("opinion_normal", ""),
                "opinion_abnormal": organ.get("opinion_abnormal", ""),
                "state_var": state_var,
                "meas_entry": meas,
            })
        self._refresh_preview()

    def _collect_patient(self):
        return {
            "name": self.name_entry.get().strip(),
            "age_sex": self.age_entry.get().strip(),
            "date": self.date_entry.get().strip() or date.today().isoformat(),
            "referred_by": self.ref_entry.get().strip(),
            "disease": (self.current_template or {}).get("disease", "") or self.disease_entry.get().strip(),
        }

    def _collect_selections(self):
        selections = []
        for row in self.organ_rows:
            selections.append({
                "organ": row["organ"],
                "state": row["state_var"].get(),
                "measurement": row["meas_entry"].get().strip(),
                "normal": row["normal"],
                "abnormal": row["abnormal"],
                "opinion_normal": row["opinion_normal"],
                "opinion_abnormal": row["opinion_abnormal"],
            })
        return selections

    def _refresh_preview(self):
        patient = self._collect_patient()
        if self.current_template and self.current_template.get("source") == "folder":
            text = ("Patient: %s | %s | %s\n\nTemplate file selected:\n%s\n\n"
                    "Open it in Word with the button above, or pick a built-in "
                    "template for the checklist builder."
                    % (patient["name"], patient["age_sex"], patient["date"],
                       self.current_template.get("file", "")))
            self.preview_box.config(state=tk.NORMAL)
            self.preview_box.delete("1.0", tk.END)
            self.preview_box.insert("1.0", text)
            self.preview_box.config(state=tk.DISABLED)
            return
        findings, opinions = assemble_report(patient, self._collect_selections())
        spoken = self.spoken_box.get("1.0", tk.END).strip()
        text = "Patient: %s | %s | %s\n\nFINDINGS\n%s\n\nOPINION\n" % (
            patient["name"], patient["age_sex"], patient["date"], findings)
        for i, line in enumerate(opinions, start=1):
            text += "%d. %s\n" % (i, line)
        if spoken:
            text += "\nSpoken notes (editable above, not part of the saved report unless copied):\n%s\n" % spoken
        self.preview_box.config(state=tk.NORMAL)
        self.preview_box.delete("1.0", tk.END)
        self.preview_box.insert("1.0", text)
        self.preview_box.config(state=tk.DISABLED)

    # ---------------- photos ----------------
    def _add_photo(self):
        paths = filedialog.askopenfilenames(
            title="Select scan photo(s)",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp"), ("All files", "*.*")])
        for p in paths:
            if p not in self.photos:
                self.photos.append(p)
        self._update_photo_label()

    def _remove_photo(self):
        if self.photos:
            self.photos.pop()
        self._update_photo_label()

    def _update_photo_label(self):
        if self.photos:
            names = ", ".join(os.path.basename(p) for p in self.photos)
            self.photo_label.config(text="%d photo(s): %s" % (len(self.photos), names))
        else:
            self.photo_label.config(text="No photos added.")

    # ---------------- save / print / new ----------------
    def _save_report(self):
        patient = self._collect_patient()
        if not patient["name"]:
            messagebox.showwarning("Missing name", "Please enter the patient name first.")
            return
        if self.current_template and self.current_template.get("source") == "folder":
            messagebox.showinfo(
                "Folder template",
                "This template comes from your templates folder and has no "
                "checklist blocks. Please open it in Word with the button "
                "above and edit it there as before, or pick a built-in "
                "template to build a checklist report.")
            return
        findings, opinions = assemble_report(patient, self._collect_selections())
        reports_dir = os.path.join(BASE_DIR, REPORTS_DIR)
        os.makedirs(reports_dir, exist_ok=True)
        filename = make_filename(patient["name"], patient["date"], patient["disease"])
        out_path = os.path.join(reports_dir, filename)
        save_docx(out_path, patient, findings, opinions, self.photos)
        append_register(os.path.join(BASE_DIR, REGISTER_FILE), patient, out_path)
        self._last_saved = out_path
        self.status.config(text="Saved: %s" % out_path)
        messagebox.showinfo("Saved", "Report saved:\n%s\n\nRegister entry added." % out_path)

    def _print_report(self):
        path = getattr(self, "_last_saved", None)
        if not path or not os.path.exists(path):
            messagebox.showinfo("Print", "Please SAVE the report first, then press PRINT.")
            return
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)  # opens in Word; print from Word
            else:
                import subprocess
                subprocess.Popen(["xdg-open", path])
            self.status.config(text="Opened in Word - print from Word (Ctrl+P).")
        except Exception as exc:
            messagebox.showerror("Print", "Could not open the file: %s" % exc)

    def _new_report(self):
        self.name_entry.delete(0, tk.END)
        self.age_entry.delete(0, tk.END)
        self.ref_entry.delete(0, tk.END)
        self.date_entry.delete(0, tk.END)
        self.date_entry.insert(0, date.today().isoformat())
        self.disease_entry.delete(0, tk.END)
        self.spoken_box.delete("1.0", tk.END)
        self.match_list.delete(0, tk.END)
        for widget in self.findings_frame.winfo_children():
            widget.destroy()
        self.organ_rows = []
        self.current_template = None
        self.photos = []
        self._update_photo_label()
        self.status.config(text="Ready for a new report.")
        self._refresh_preview()


if __name__ == "__main__":
    app = SonoReportApp()
    app.mainloop()
